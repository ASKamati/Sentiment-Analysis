import pandas as pd
import re
import string
import pickle

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Step 1: Load dataset
file_path = "sentiment_dataset.csv"
data = pd.read_csv(file_path)

print("First 5 rows:")
print(data.head())
print("\nColumns in dataset:")
print(data.columns)

# Set your dataset column names
text_column = "text"
label_column = "label"

# Step 2: Keep required columns and remove missing values
data = data[[text_column, label_column]].dropna()

# Step 3: Clean text
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+|https\S+", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text

data[text_column] = data[text_column].apply(clean_text)

# Step 4: Convert labels
data[label_column] = data[label_column].astype(str).str.lower().str.strip()

label_mapping = {
    "positive": 1,
    "negative": 0
}

data = data[data[label_column].isin(label_mapping.keys())]
data[label_column] = data[label_column].map(label_mapping)

# Step 5: Split dataset
X = data[text_column]
y = data[label_column]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Step 6: Build model pipeline
model = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english", max_features=5000)),
    ("classifier", LogisticRegression(max_iter=1000))
])

# Step 7: Train model
model.fit(X_train, y_train)

# Step 8: Evaluate model
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("\nModel Accuracy:", accuracy)

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Step 9: Save model
with open("sentiment_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("\nModel saved as sentiment_model.pkl")